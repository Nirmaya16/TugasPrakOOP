package Latihan3;

public class Karyawan {
    public static void main(String[] args) {
        System.out.println("--------Program detail Karyawan------");
        // namakelas  namaObjek  = new namakelas();
        dataKaryawan dataKaryawan = new dataKaryawan();
        dataKaryawan.display();
    }
}
