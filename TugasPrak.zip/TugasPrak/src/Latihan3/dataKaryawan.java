package Latihan3;

public class dataKaryawan {
    // Akses dasar terhadap variabel nama, jabatan, dan umur
    private String nama = "Fuad Maharana";
    private String jabatan = "Software Analyst";
    private int umur = 28;

    // akses dasar terhadap method
    public void display()
    {
        // Output
        System.out.println("Nama : " + nama);
        System.out.println("Jabatan : " + jabatan);
        System.out.println("Umur : " + umur);
    }
}
