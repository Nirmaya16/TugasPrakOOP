package Latihan1;

public class KonversiSuhu {
    public static void main(String[] args) {
        Suhu suhu = new Suhu();
        suhu.menu();
        suhu.input();
        suhu.konversi();
    }
}
